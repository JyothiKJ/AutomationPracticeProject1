package Logic;


import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.github.javafaker.PhoneNumber;

import static Logic.LaunchBrowsers.*;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import Pages.HomePages;

public class AutomationTestingWebPageLogic {
	
	
		// constructor
		public static WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		 /** 1.
	     * Method to verify user navigated to practice automation testing home page by fetching current url & comparing with actual url.
		 * @throws InterruptedException 
	     */
	    public static void verifyHomePageNavigation(){
	        String homePageUrl = driver.getCurrentUrl();
	        Assert.assertEquals(homePageUrl,"http://practice.automationtesting.in/","Not navigated to homepage home page");
	        System.out.println("Home page url is: " + homePageUrl);
	        
	    }

	          

	    //}
	    
	    @Test
		/*public static String automationSignupTest()
		{
			Faker faker = new Faker();
			faker.name();
			String firstName = faker.name().firstName();
			String lastName = faker.name().lastName(); 
			String email = firstName.toLowerCase() + "." + lastName.toLowerCase() + "@domain.com";
			return email;
					}
	  	   */
	       
	    public static void navigateToMyaccountPage() throws InterruptedException {
	    	
	    	Faker faker = new Faker();
			faker.name();
			String city = faker.address().city();
			String address = faker.address().cityName();
			PhoneNumber phone_No = faker.phoneNumber();
			
			String firstName = faker.name().firstName();
			String lastName = faker.name().lastName(); 
			String email = firstName.toLowerCase() + "." + lastName.toLowerCase() + "@domain.com";
	    	
	    	driver.findElement(HomePages.objMyAcc);
	    	driver.findElement(HomePages.objMyAcc).click();
	    	Thread.sleep(5000);
	    	
	    	
	    	//wait.until(ExpectedConditions.presenceOfElementLocated(HomePages.objRegEmail));
	    	 
	    	  System.out.println("Email: " + email);
	    	
	    	driver.findElement(HomePages.objRegEmail).sendKeys(email);
	    	
	    	driver.findElement(HomePages.objRegPassword).sendKeys("Igs@123!$%45&^&%^$!");
	    	
	    	Thread.sleep(10000);
	    	
	    	
	     	driver.findElement(HomePages.objRegister);
	    	driver.findElement(HomePages.objRegister).click();
	    	
	    	driver.findElement(HomePages.objAdresses);
	    	driver.findElement(HomePages.objAdresses).click();
	    	
	    	wait.until(ExpectedConditions.presenceOfElementLocated(HomePages.objAdresses));
	    	driver.findElement(HomePages.objEdit);
	    	driver.findElement(HomePages.objEdit).click();
	    	
	    	//Providing Name and Address Details------
	    	
	    	wait.until(ExpectedConditions.presenceOfElementLocated(HomePages.ObjFirstname));
	    	driver.findElement(HomePages.ObjFirstname).sendKeys(firstName);
	    	driver.findElement(HomePages.ObjLastname).sendKeys(lastName);
	    	driver.findElement(HomePages.ObjPhone).sendKeys("8877660044");
	    	driver.findElement(HomePages.ObjAddAdress).sendKeys("JP Nagar 2nd Phase");
	    	driver.findElement(HomePages.ObjCity).sendKeys("Bengaluru");
	    	driver.findElement(HomePages.ObjState).click();
	    	
	    	WebElement searchbox = driver.findElement(HomePages.ObjSearchState);
	    	searchbox.sendKeys("Kerala");
	    		    	
	    	searchbox.sendKeys(Keys.ENTER);
	    	Thread.sleep(1000);

	    	driver.findElement(HomePages.ObjPincode).sendKeys("560078");
	    	driver.findElement(HomePages.objsaveAddress);
	    	driver.findElement(HomePages.objsaveAddress).click();
	    	
	    	wait.until(ExpectedConditions.presenceOfElementLocated(HomePages.objLogout));
	    	driver.findElement(HomePages.objLogout);
	    	driver.findElement(HomePages.objLogout).click();
	    	}

		/*private static String AutomationsignupTest() {
			// TODO Auto-generated method stub
			return null;
		}*/
	    
}


/*package Logic;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import static Logic.LaunchBrowsers.*;

import java.time.Duration;

import Pages.HomePages;

public class VootHomePageLogic {
	// constructor
	public static WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
	 /** 1.
     * Method to verify user navigated to voot home page by fetching current url & comparing with actual url.
     */
   /* public static void verifyHomePageNavigation(){
        String homePageUrl = driver.getCurrentUrl();
        Assert.assertEquals(homePageUrl,"https://www.voot.com/","Not navigated to Voot home page");
        System.out.println("Home page url is: " + homePageUrl);
    }

    /** 2.
     * method to verify voot logo by presence of element and comparing fetched logo text with actual text.
     */
    /*public static void verifyVootLogo(){
        WebElement vootlogo = driver.findElement(HomePages.objVootLogo);
        String logoText = vootlogo.getAttribute("title");
        String title = driver.getTitle();
        System.out.println("Title is: " + title);
        System.out.println("Text of voot logo is: " + logoText);
        Assert.assertEquals(logoText,"Voot","Failed to fetch voot logo");
        Assert.assertTrue(vootlogo.isDisplayed(), "Voot logo not displayed");

    }
    public static void navigateToPremiumpage() {
    	driver.findElement(HomePages.objPremiumTab);
    	driver.findElement(HomePages.objPremiumTab).click();
    	wait.until(ExpectedConditions.presenceOfElementLocated(HomePages.objCarouselCardOnPremiumTab));
    	
    }

}*/

