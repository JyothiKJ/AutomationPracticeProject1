package Pages;
import org.openqa.selenium.By;

public class HomePages {
	
	public static By objMyAcc = By.xpath("//a[contains(text(),'My Account')]");
	public static By objRegEmail = By.xpath("//input[@id='reg_email']");
	public static By objRegPassword = By.xpath("//input[@id='reg_password']");
	public static By objRegister = By.xpath("//input[@value='Register']");
	public static By objAdresses = By.xpath("//a[contains(text(), 'Addresses')]");
	public static By ObjBillingAdress = By.xpath("//header[@class='woocommerce-Address-title title']//h3[text()='Billing Address']");
	public static By objEdit = By.xpath("(//a[@class='edit'])[1]");
	public static By ObjFirstname = By.xpath("//input[@name='billing_first_name']");
	public static By ObjLastname = By.xpath("//input[@id='billing_last_name']");
	public static By ObjPhone = By.xpath("//input[@id='billing_phone']");
	public static By ObjAddAdress = By.xpath("//input[@id='billing_address_1']"); 
	public static By ObjCity = By.xpath("//input[@name='billing_city']"); 
	public static By ObjState = By.xpath("//span[@id='select2-chosen-2']");
	public static By ObjSearchState = By.xpath("//input[@id='s2id_autogen2_search']");
	public static By ObjPincode = By.xpath("//input[@id='billing_postcode']");
	public static By objsaveAddress = By.xpath("//input[@value='Save Address']");
	public static By objLogout = By.xpath("//a[contains(text(),'Logout')]");
}
