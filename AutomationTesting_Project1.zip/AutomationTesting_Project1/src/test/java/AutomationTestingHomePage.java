import org.testng.annotations.Test;

import Logic.AutomationTestingWebPageLogic;
import Logic.LaunchBrowsers;
import Logic.AutomationTestingWebPageLogic;

/* public class VootHome extends LaunchBrowsers {
	 /**
     * Method to verify UI element in voot home page
     */
 /*   @Test
    public void homePagevalidation(){
        VootHomePageLogic.verifyHomePageNavigation();
        VootHomePageLogic.verifyVootLogo();
        VootHomePageLogic.navigateToPremiumpage();
    }

} */

public class AutomationTestingHomePage extends LaunchBrowsers {
	
	@Test
	/**
     * Method to verify UI element in Automation Practice home page
     */
       public void homePagevalidation() throws InterruptedException{
		AutomationTestingWebPageLogic.verifyHomePageNavigation();
        //AutomationTestingWebPageLogic.automationSignupTest();
        AutomationTestingWebPageLogic.navigateToMyaccountPage();
       
        
    }
}
